#include <stdio.h>

int main(void)
{
	printf("I like programming \n");
	printf("I love puppy! \n");
	printf("I am so happy \n");
	return 0;
}
