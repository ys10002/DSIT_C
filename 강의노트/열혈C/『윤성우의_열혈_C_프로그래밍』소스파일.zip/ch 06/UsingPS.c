#include <stdio.h>

int main(void)
{
	printf("%s, %s, %s \n", "AAA", "BBB", "CCC");
	return 0;
}
