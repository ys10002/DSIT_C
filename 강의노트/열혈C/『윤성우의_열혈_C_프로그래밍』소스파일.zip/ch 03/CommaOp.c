#include <stdio.h>

int main(void)
{
	int num1=1, num2=2;
	printf("Hello "), printf("world! \n");
	num1++, num2++;
	printf("%d ", num1), printf("%d ", num2), printf("\n");
	return 0;
}