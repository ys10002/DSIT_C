#include <stdio.h>

int main(void)
{
	3+4;
	return 0;
}