#include "stdiv.h"

Div IntDiv(int num1, int num2);