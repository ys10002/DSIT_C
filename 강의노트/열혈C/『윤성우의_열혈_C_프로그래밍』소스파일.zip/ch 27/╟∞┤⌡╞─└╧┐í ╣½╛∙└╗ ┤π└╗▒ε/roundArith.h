double RectangleRound(double base, double height);

double SquareRound(double side);