int cnt=0;

void AddCnt(void)
{
	cnt++;
}

void MinCnt(void)
{
	cnt--;
}

int GetCnt(void)
{
	return cnt;
}