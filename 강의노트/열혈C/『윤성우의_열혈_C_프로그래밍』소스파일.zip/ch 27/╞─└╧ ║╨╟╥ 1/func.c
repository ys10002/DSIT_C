extern int num;

void Increment(void)
{
	num++;
}

int GetNum(void)
{
	return num;
}